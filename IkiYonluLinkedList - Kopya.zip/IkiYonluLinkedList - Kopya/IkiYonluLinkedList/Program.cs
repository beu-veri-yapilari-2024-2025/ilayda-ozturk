﻿using System;
using System.Linq;

public class DoublyNode<T>
{
    public T Data;
    public DoublyNode<T> Next;
    public DoublyNode<T> Prev;

    public DoublyNode(T data)
    {
        Data = data;
        Next = null;
        Prev = null;
    }
}

public class DoublyLinkedList<T>
{
    private DoublyNode<T> head;
    private DoublyNode<T> tail;
    public int Count { get; set; }

    public DoublyLinkedList()
    {
        head = null;
        tail = null;
        Count = 0;
    }

    public void AddFirst(T data)
    {
        DoublyNode<T> newNode = new DoublyNode<T>(data);
        if (head == null)
        {
            head = newNode;
            tail = newNode;
        }

        else
        {
            newNode.Next = head;
            head.Prev = newNode;
            head = newNode;
        }
        Count++;
        Console.WriteLine($"'{data}' başa eklendi.");
    }

    public void AddLast(T data)
    {
        DoublyNode<T> newNode = new DoublyNode<T>(data);
        if (tail == null)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            newNode.Prev = tail;
            tail.Next = newNode;
            tail = newNode;
        }
        Count++;
        Console.WriteLine($"'{data}' sona eklendi.");
    }

    public bool AddAfter(T existingData, T newData)
    {
        DoublyNode<T> current = head;
        while (current != null)
        {
            if (current.Data.Equals(existingData))
            {
                DoublyNode<T> newNode = new DoublyNode<T>(newData);
                newNode.Next = current.Next;
                newNode.Prev = current;

                if (current.Next != null)
                {
                    current.Next.Prev = newNode;
                }
                else
                {
                    tail = newNode; // Eğer son düğüm ise, kuyruk (tail) güncellenir.
                }

                current.Next = newNode;
                Count++;
                Console.WriteLine($"'{newData}', '{existingData}' verisinden SONRA eklendi.");
                return true;
            }
            current = current.Next;
        }
        Console.WriteLine($"Hata: Liste içinde '{existingData}' verisi bulunamadı. Ekleme yapılmadı.");
        return false;
    }

    public bool AddBefore(T existingData, T newData)
    {
        if (head == null)
        {
            Console.WriteLine($"Hata: Liste boş. Ekleme yapılmadı.");
            return false;
        }

        if (head.Data.Equals(existingData))
        {
            AddFirst(newData); // Başa ekleme işlemini kullan
            return true;
        }

        DoublyNode<T> current = head.Next;
        while (current != null)
        {
            if (current.Data.Equals(existingData))
            {
                DoublyNode<T> newNode = new DoublyNode<T>(newData);

                newNode.Prev = current.Prev;
                newNode.Next = current;

                current.Prev.Next = newNode;
                current.Prev = newNode;

                Count++;
                Console.WriteLine($"'{newData}', '{existingData}' verisinden ÖNCE eklendi.");
                return true;
            }
            current = current.Next;
        }
        Console.WriteLine($"Hata: Liste içinde '{existingData}' verisi bulunamadı. Ekleme yapılmadı.");
        return false;
    }

    public T RemoveFirst()
    {
        if (head == null)
        {
            throw new InvalidOperationException("Liste boş, silme yapılamaz.");
        }

        T data = head.Data;

        if (head == tail) // Tek eleman varsa
        {
            head = null;
            tail = null;
        }
        else
        {
            head = head.Next;
            head.Prev = null;
        }
        Count--;
        Console.WriteLine($"Baştan silindi: '{data}'.");
        return data;
    }

    public T RemoveLast()
    {
        if (tail == null)
        {
            throw new InvalidOperationException("Liste boş, silme yapılamaz.");
        }

        T data = tail.Data;

        if (head == tail) // Tek eleman varsa
        {
            head = null;
            tail = null;
        }
        else
        {
            tail = tail.Prev;
            tail.Next = null;
        }
        Count--;
        Console.WriteLine($"Sondan silindi: '{data}'.");
        return data;
    }

    public bool Remove(T dataToRemove)
    {
        DoublyNode<T> current = head;
        while (current != null)
        {
            if (current.Data.Equals(dataToRemove))
            {
                if (current == head)
                {
                    RemoveFirst();
                    return true;
                }
                if (current == tail)
                {
                    RemoveLast();
                    return true;
                }

                // Aradan silme işlemi
                current.Prev.Next = current.Next;
                current.Next.Prev = current.Prev;

                Count--;
                Console.WriteLine($"Aradan silindi: '{dataToRemove}'.");
                return true;
            }
            current = current.Next;
        }
        Console.WriteLine($"Hata: Liste içinde '{dataToRemove}' verisi bulunamadı. Silme yapılmadı.");
        return false;
    }

    public bool Search(T dataToFind)
    {
        DoublyNode<T> current = head;
        int position = 0;
        while (current != null)
        {
            if (current.Data.Equals(dataToFind))
            {
                Console.WriteLine($"Arama başarılı: '{dataToFind}' verisi {position}. pozisyonda bulundu.");
                return true;
            }
            current = current.Next;
            position++;
        }
        Console.WriteLine($"Arama başarısız: '{dataToFind}' verisi listede bulunamadı.");
        return false;
    }

    public void DisplayList()
    {
        if (head == null)
        {
            Console.WriteLine("Liste boş.");
            return;
        }

        Console.Write("Liste elemanları: ");
        DoublyNode<T> current = head;
        while (current != null)
        {
            Console.Write($"[{current.Data}]");
            if (current.Next != null)
            {
                Console.Write(" <-> ");
            }
            current = current.Next;
        }
        Console.WriteLine();
        Console.WriteLine($"Toplam eleman sayısı: {Count}");
    }

    public void Clear()
    {
        head = null;
        tail = null;
        Count = 0;
        Console.WriteLine("Liste başarıyla temizlendi.");
    }

    public T[] ToArray()
    {
        T[] array = new T[Count];
        DoublyNode<T> current = head;
        int index = 0;

        while (current != null)
        {
            array[index] = current.Data;
            current = current.Next;
            index++;
        }

        Console.Write("Liste diziye aktarıldı: ");
        Console.WriteLine("[" + string.Join(", ", array.Select(x => x.ToString())) + "]");
        return array;
    }

}

public class Program
{
    public static void Main(string[] args)
    {
        DoublyLinkedList<int> liste = new DoublyLinkedList<int>();

        Console.WriteLine("--- İki Yönlü Bağlı Liste Örneği ---");

        
        liste.AddFirst(10); // [10]

        
        liste.AddLast(20); 
        liste.AddLast(30);
        liste.AddFirst(5); 

        
        liste.DisplayList();

        
        liste.AddAfter(20, 25); 
        liste.AddAfter(30, 40); 

        
        liste.AddBefore(10, 8); 
        liste.AddBefore(5, 3);  

        liste.DisplayList();

        
        liste.Search(25);
        liste.Search(100);

        Console.WriteLine("\n--- Silme İşlemleri ---");

        
        liste.RemoveFirst(); 

        
        liste.RemoveLast(); 

        
        liste.Remove(10); 
        liste.Remove(500); 

        liste.DisplayList();

        
        int[] dizi = liste.ToArray();

        Console.WriteLine("\n--- Temizleme İşlemi ---");
        
        liste.Clear();
        liste.DisplayList();
    }
}