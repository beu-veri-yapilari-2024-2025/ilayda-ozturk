﻿using System;
using System.Collections.Generic;

namespace SporKulubuBST
{
    // 1. ADIM: Düğüm (Node) Sınıfının Tasarımı
    public class OyuncuDugum
    {
        public int FormaNo;
        public string Ad;
        public string Soyad;
        public OyuncuDugum Sol;
        public OyuncuDugum Sag;

        public OyuncuDugum(int formaNo, string ad, string soyad)
        {
            this.FormaNo = formaNo;
            this.Ad = ad;
            this.Soyad = soyad;
            this.Sol = null;
            this.Sag = null;
        }
    }

    // 2. ADIM: Binary Search Tree (BST) Sınıfı
    public class TakimBST
    {
        public OyuncuDugum Kok; // Root

        public TakimBST()
        {
            Kok = null;
        }

        // --- EKLEME (INSERT) ---
        public void Ekle(int formaNo, string ad, string soyad)
        {
            Kok = EkleRecursive(Kok, formaNo, ad, soyad);
        }

        private OyuncuDugum EkleRecursive(OyuncuDugum dugum, int formaNo, string ad, string soyad)
        {
            // Eğer ağaç boşsa veya yaprak düğüme gelindiyse yeni düğümü oluştur
            if (dugum == null)
            {
                return new OyuncuDugum(formaNo, ad, soyad);
            }

            // Forma numarasına göre yönlendirme (BST Kuralı)
            if (formaNo < dugum.FormaNo)
            {
                dugum.Sol = EkleRecursive(dugum.Sol, formaNo, ad, soyad);
            }
            else if (formaNo > dugum.FormaNo)
            {
                dugum.Sag = EkleRecursive(dugum.Sag, formaNo, ad, soyad);
            }
            else
            {
                Console.WriteLine($"HATA: {formaNo} numaralı oyuncu zaten takımda var!");
            }

            return dugum;
        }

        // --- ARAMA (SEARCH) ---
        public void Ara(int formaNo)
        {
            OyuncuDugum sonuc = AraRecursive(Kok, formaNo);
            if (sonuc != null)
                Console.WriteLine($"BULUNDU: No: {sonuc.FormaNo} | {sonuc.Ad} {sonuc.Soyad}");
            else
                Console.WriteLine($"ARAMA SONUCU: {formaNo} numaralı oyuncu bulunamadı.");
        }

        private OyuncuDugum AraRecursive(OyuncuDugum dugum, int formaNo)
        {
            if (dugum == null || dugum.FormaNo == formaNo)
                return dugum;

            if (formaNo < dugum.FormaNo)
                return AraRecursive(dugum.Sol, formaNo);

            return AraRecursive(dugum.Sag, formaNo);
        }

        // --- SİLME (DELETE) ---
        public void Sil(int formaNo)
        {
            Kok = SilRecursive(Kok, formaNo);
        }

        private OyuncuDugum SilRecursive(OyuncuDugum dugum, int formaNo)
        {
            if (dugum == null) return null;

            // 1. Silinecek düğümü bulma aşaması
            if (formaNo < dugum.FormaNo)
            {
                dugum.Sol = SilRecursive(dugum.Sol, formaNo);
            }
            else if (formaNo > dugum.FormaNo)
            {
                dugum.Sag = SilRecursive(dugum.Sag, formaNo);
            }
            else
            {
                // Düğüm bulundu, silme işlemi başlıyor:

                // Durum 1: Tek çocuklu veya çocuksuz düğüm
                if (dugum.Sol == null) return dugum.Sag;
                if (dugum.Sag == null) return dugum.Sol;

                // Durum 2: İki çocuklu düğüm
                // Sağ alt ağacın en küçüğünü (Inorder Successor) bul ve yerine koy
                OyuncuDugum halef = EnKucukDugumuBul(dugum.Sag);
                dugum.FormaNo = halef.FormaNo;
                dugum.Ad = halef.Ad;
                dugum.Soyad = halef.Soyad;

                // Halefi eski yerinden sil
                dugum.Sag = SilRecursive(dugum.Sag, halef.FormaNo);
            }
            return dugum;
        }

        // --- EN KÜÇÜK VE EN BÜYÜK BULMA ---
        public OyuncuDugum EnKucukDugumuBul(OyuncuDugum dugum)
        {
            OyuncuDugum mevcut = dugum;
            while (mevcut.Sol != null)
            {
                mevcut = mevcut.Sol;
            }
            return mevcut;
        }

        public void EnKucukYazdir()
        {
            if (Kok == null) { Console.WriteLine("Takım boş."); return; }
            OyuncuDugum enKucuk = EnKucukDugumuBul(Kok);
            Console.WriteLine($"En Küçük Forma No: {enKucuk.FormaNo} ({enKucuk.Ad} {enKucuk.Soyad})");
        }

        public void EnBuyukYazdir()
        {
            if (Kok == null) { Console.WriteLine("Takım boş."); return; }
            OyuncuDugum mevcut = Kok;
            while (mevcut.Sag != null)
            {
                mevcut = mevcut.Sag;
            }
            Console.WriteLine($"En Büyük Forma No: {mevcut.FormaNo} ({mevcut.Ad} {mevcut.Soyad})");
        }

        // --- LİSTELEME (TRAVERSALS) ---

        // 1. Preorder (Kök - Sol - Sağ)
        public void PreOrder(OyuncuDugum dugum)
        {
            if (dugum != null)
            {
                Console.Write($"[{dugum.FormaNo}-{dugum.Ad}] ");
                PreOrder(dugum.Sol);
                PreOrder(dugum.Sag);
            }
        }

        // 2. Inorder (Sol - Kök - Sağ) -> Küçükten büyüğe sıralar
        public void InOrder(OyuncuDugum dugum)
        {
            if (dugum != null)
            {
                InOrder(dugum.Sol);
                Console.Write($"[{dugum.FormaNo}-{dugum.Ad}] ");
                InOrder(dugum.Sag);
            }
        }

        // 3. Postorder (Sol - Sağ - Kök)
        public void PostOrder(OyuncuDugum dugum)
        {
            if (dugum != null)
            {
                PostOrder(dugum.Sol);
                PostOrder(dugum.Sag);
                Console.Write($"[{dugum.FormaNo}-{dugum.Ad}] ");
            }
        }

        // 4. Level Order (Breadth-First Search) - Katman Katman
        public void LevelOrder()
        {
            if (Kok == null) return;

            Queue<OyuncuDugum> kuyruk = new Queue<OyuncuDugum>();
            kuyruk.Enqueue(Kok);

            while (kuyruk.Count > 0)
            {
                OyuncuDugum gecici = kuyruk.Dequeue();
                Console.Write($"[{gecici.FormaNo}-{gecici.Ad}] ");

                if (gecici.Sol != null) kuyruk.Enqueue(gecici.Sol);
                if (gecici.Sag != null) kuyruk.Enqueue(gecici.Sag);
            }
        }
    }

    // 3. ADIM: Test ve Çalıştırma (Main)
    class Program
    {
        static void Main(string[] args)
        {
            TakimBST takim = new TakimBST();

            Console.WriteLine("--- SPOR KULÜBÜ KAYIT SİSTEMİ ---");

            // ÖZEL KURAL: Kaleci Takımın Kökü Olacaktır.
            // Bu yüzden ilk olarak kaleciyi ekliyoruz (Genelde 1 numara olur)
            // Ancak BST kuralı gereği Root orta değerde olursa ağaç daha dengeli olur.
            // Fakat ödevde "İlk eklenecek oyuncu kaleci olmalı" dendiği için
            // Kaleciyi (Örn: Muslera, No: 1) ilk ekliyoruz.
            // Not: Eğer kaleci 1 numara ise ağaç sadece sağa doğru büyüyen (skewed) bir yapı olabilir,
            // ama kurala uymak zorundayız.

            Console.WriteLine("\n>> Oyuncular Ekleniyor...");
            takim.Ekle(1, "Fernando", "Muslera"); // KÖK (ROOT)
            takim.Ekle(10, "Dries", "Mertens");
            takim.Ekle(9, "Mauro", "Icardi");
            takim.Ekle(25, "Victor", "Nelsson");
            takim.Ekle(7, "Kerem", "Akturkoglu");
            takim.Ekle(53, "Baris", "Yilmaz");
            takim.Ekle(4, "Ismail", "Jakobs");

            // LİSTELEME İŞLEMLERİ
            Console.WriteLine("\n\n--- PreOrder Dolaşım (Kök-Sol-Sağ) ---");
            takim.PreOrder(takim.Kok);

            Console.WriteLine("\n\n--- InOrder Dolaşım (Küçükten Büyüğe Sıralı) ---");
            takim.InOrder(takim.Kok);

            Console.WriteLine("\n\n--- PostOrder Dolaşım (Sol-Sağ-Kök) ---");
            takim.PostOrder(takim.Kok);

            Console.WriteLine("\n\n--- Level Order Dolaşım (Satır Satır) ---");
            takim.LevelOrder();

            // ARAMA İŞLEMİ
            Console.WriteLine("\n\n--- Arama İşlemi ---");
            takim.Ara(9); // Icardi'yi ara
            takim.Ara(99); // Olmayan oyuncu

            // MİN - MAX BULMA
            Console.WriteLine("\n--- Min ve Max Forma Numaraları ---");
            takim.EnKucukYazdir();
            takim.EnBuyukYazdir();

            // SİLME İŞLEMİ
            Console.WriteLine("\n--- Silme İşlemi (No: 7 Kerem siliniyor) ---");
            takim.Sil(7);

            Console.Write("Silindikten sonra InOrder Listesi: ");
            takim.InOrder(takim.Kok);

            Console.WriteLine("\n\nProgramı kapatmak için bir tuşa basın...");
            Console.ReadKey();
        }
    }
}