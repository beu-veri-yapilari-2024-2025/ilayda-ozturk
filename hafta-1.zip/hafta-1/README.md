1. haftanın ilk üç ödevi aşağıda verilmiş dosyalardadır. 

Birinci ödevde binary search yapılmış ve notasyonu gösterilmiştir.

İkinci ödevde ise dizideki elemanlar toplanmış ve notasyonu belirtilmiştir.

En son ödevde ise matris çarpımı ve notasyonuna yer verilmiştir.