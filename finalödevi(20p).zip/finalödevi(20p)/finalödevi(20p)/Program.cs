﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SortingAlgorithmsApp
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== SIRALAMA ALGORİTMALARI PROJESİ ===");
                Console.WriteLine("Lütfen sıralanacak sayıları aralarında virgül veya boşluk bırakarak giriniz:");
                Console.WriteLine("(Örnek: 12, 7, 14, 9, 10, 11)");

                string input = Console.ReadLine();
                int[] array;

                try
                {
                    array = input.Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                                 .Select(int.Parse)
                                 .ToArray();
                }
                catch
                {
                    Console.WriteLine("Hatalı giriş! Lütfen sadece sayı giriniz.");
                    Console.ReadKey();
                    continue;
                }

                Console.WriteLine("\n--- Algoritma Seçimi ---");
                Console.WriteLine("1. Bubble Sort");
                Console.WriteLine("2. Selection Sort");
                Console.WriteLine("3. Insertion Sort");
                Console.WriteLine("4. Shell Sort");
                Console.WriteLine("-----------------------");
                Console.WriteLine("5. Heap Sort");
                Console.WriteLine("6. Merge Sort");
                Console.WriteLine("7. Quick Sort");
                Console.WriteLine("-----------------------");
                Console.WriteLine("8. Radix Sort");
                Console.WriteLine("9. Bucket Sort");
                Console.Write("\nSeçiminiz (1-9): ");

                string choice = Console.ReadLine();
                int[] tempArray = (int[])array.Clone(); // Orijinal diziyi bozmamak için kopya

                Console.WriteLine("\n=== BAŞLANGIÇ DİZİSİ ===");
                PrintArray(tempArray);
                Console.WriteLine("========================\n");

                switch (choice)
                {
                    case "1":
                        ShowComplexity("Bubble Sort", "O(n)", "O(n^2)", "O(n^2)");
                        BubbleSort(tempArray);
                        break;
                    case "2":
                        ShowComplexity("Selection Sort", "O(n^2)", "O(n^2)", "O(n^2)");
                        SelectionSort(tempArray);
                        break;
                    case "3":
                        ShowComplexity("Insertion Sort", "O(n)", "O(n^2)", "O(n^2)");
                        InsertionSort(tempArray);
                        break;
                    case "4":
                        ShowComplexity("Shell Sort", "O(n log n)", "O(n log n)", "O(n^2)");
                        ShellSort(tempArray);
                        break;
                    case "5":
                        ShowComplexity("Heap Sort", "O(n log n)", "O(n log n)", "O(n log n)");
                        HeapSort(tempArray);
                        break;
                    case "6":
                        ShowComplexity("Merge Sort", "O(n log n)", "O(n log n)", "O(n log n)");
                        MergeSort(tempArray, 0, tempArray.Length - 1);
                        break;
                    case "7":
                        ShowComplexity("Quick Sort", "O(n log n)", "O(n log n)", "O(n^2)");
                        QuickSort(tempArray, 0, tempArray.Length - 1);
                        break;
                    case "8":
                        ShowComplexity("Radix Sort", "O(nk)", "O(nk)", "O(nk)");
                        RadixSort(tempArray);
                        break;
                    case "9":
                        ShowComplexity("Bucket Sort", "O(n+k)", "O(n)", "O(n^2)");
                        BucketSort(tempArray);
                        break;
                    default:
                        Console.WriteLine("Geçersiz seçim!");
                        break;
                }

                Console.WriteLine("\nSıralama tamamlandı. Tekrar denemek için bir tuşa basın...");
                Console.ReadKey();
            }
        }

        // --- YARDIMCI METOTLAR ---
        static void PrintArray(int[] arr, string message = "")
        {
            if (!string.IsNullOrEmpty(message)) Console.Write(message + " -> ");
            Console.WriteLine("[" + string.Join(", ", arr) + "]");
        }

        static void ShowComplexity(string name, string best, string avg, string worst)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"*** {name} Karmaşıklık Bilgisi ***");
            Console.WriteLine($"En İyi (Best): {best}");
            Console.WriteLine($"Ortalama (Average): {avg}");
            Console.WriteLine($"En Kötü (Worst): {worst}");
            Console.ResetColor();
            Console.WriteLine("---------------------------------\n");
        }

        
        // 1. GRUP: TEMEL ALGORİTMALAR
      

        static void BubbleSort(int[] arr)
        {
            int n = arr.Length;
            for (int i = 0; i < n - 1; i++)
            {
                bool swapped = false;
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                        swapped = true;
                    }
                }
                PrintArray(arr, $"Adım {i + 1}");
                if (!swapped) break; // Zaten sıralıysa erken bitir
            }
        }

        static void SelectionSort(int[] arr)
        {
            int n = arr.Length;
            for (int i = 0; i < n - 1; i++)
            {
                int minIdx = i;
                for (int j = i + 1; j < n; j++)
                    if (arr[j] < arr[minIdx])
                        minIdx = j;

                int temp = arr[minIdx];
                arr[minIdx] = arr[i];
                arr[i] = temp;

                PrintArray(arr, $"Adım {i + 1} (En küçük {arr[i]} başa alındı)");
            }
        }

        static void InsertionSort(int[] arr)
        {
            int n = arr.Length;
            for (int i = 1; i < n; ++i)
            {
                int key = arr[i];
                int j = i - 1;

                while (j >= 0 && arr[j] > key)
                {
                    arr[j + 1] = arr[j];
                    j = j - 1;
                }
                arr[j + 1] = key;
                PrintArray(arr, $"Adım {i} ({key} araya yerleştirildi)");
            }
        }

        static void ShellSort(int[] arr)
        {
            int n = arr.Length;
            int stepCounter = 1;
            // Gap (aralık) yarıya inerek devam eder
            for (int gap = n / 2; gap > 0; gap /= 2)
            {
                for (int i = gap; i < n; i += 1)
                {
                    int temp = arr[i];
                    int j;
                    for (j = i; j >= gap && arr[j - gap] > temp; j -= gap)
                        arr[j] = arr[j - gap];
                    arr[j] = temp;
                }
                PrintArray(arr, $"Gap ({gap}) Adımı {stepCounter++}");
            }
        }

        // 2. GRUP: VERİMLİ ALGORİTMALAR
        

        static void HeapSort(int[] arr)
        {
            int n = arr.Length;

            // Heap oluşturma
            for (int i = n / 2 - 1; i >= 0; i--)
                Heapify(arr, n, i);

            PrintArray(arr, "Max Heap Oluşturuldu");

            // Elemanları tek tek çekme
            for (int i = n - 1; i > 0; i--)
            {
                int temp = arr[0];
                arr[0] = arr[i];
                arr[i] = temp;

                Heapify(arr, i, 0);
                PrintArray(arr, $"Kök eleman sona atıldı, kalan heaplendi");
            }
        }

        static void Heapify(int[] arr, int n, int i)
        {
            int largest = i;
            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if (left < n && arr[left] > arr[largest])
                largest = left;

            if (right < n && arr[right] > arr[largest])
                largest = right;

            if (largest != i)
            {
                int swap = arr[i];
                arr[i] = arr[largest];
                arr[largest] = swap;
                Heapify(arr, n, largest);
            }
        }

        static void MergeSort(int[] arr, int left, int right)
        {
            if (left < right)
            {
                int mid = (left + right) / 2;

                MergeSort(arr, left, mid);
                MergeSort(arr, mid + 1, right);

                Merge(arr, left, mid, right);
                // Recursive olduğu için her birleştirmede yazdırıyoruz
                PrintArray(arr, $"Merge ({left}-{right}) Birleştirildi");
            }
        }

        static void Merge(int[] arr, int left, int mid, int right)
        {
            int n1 = mid - left + 1;
            int n2 = right - mid;
            int[] L = new int[n1];
            int[] R = new int[n2];

            for (int i = 0; i < n1; ++i) L[i] = arr[left + i];
            for (int j = 0; j < n2; ++j) R[j] = arr[mid + 1 + j];

            int k = left;
            int x = 0, y = 0;

            while (x < n1 && y < n2)
            {
                if (L[x] <= R[y]) arr[k++] = L[x++];
                else arr[k++] = R[y++];
            }
            while (x < n1) arr[k++] = L[x++];
            while (y < n2) arr[k++] = R[y++];
        }

        static void QuickSort(int[] arr, int low, int high)
        {
            if (low < high)
            {
                int pi = Partition(arr, low, high);

                PrintArray(arr, $"Pivot ({arr[pi]}) yerleşti, Dizi bölündü");

                QuickSort(arr, low, pi - 1);
                QuickSort(arr, pi + 1, high);
            }
        }

        static int Partition(int[] arr, int low, int high)
        {
            int pivot = arr[high];
            int i = (low - 1);
            for (int j = low; j < high; j++)
            {
                if (arr[j] < pivot)
                {
                    i++;
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
            int temp1 = arr[i + 1];
            arr[i + 1] = arr[high];
            arr[high] = temp1;
            return i + 1;
        }

        
        // 3. GRUP: DAĞILIMLI ALGORİTMALAR
        

        static void RadixSort(int[] arr)
        {
            int m = arr.Max();
            // Basamak basamak 
            for (int exp = 1; m / exp > 0; exp *= 10)
            {
                CountSortForRadix(arr, exp);
                PrintArray(arr, $"{exp}'ler basamağına göre sıralandı");
            }
        }

        static void CountSortForRadix(int[] arr, int exp)
        {
            int n = arr.Length;
            int[] output = new int[n];
            int[] count = new int[10];

            for (int i = 0; i < n; i++)
                count[(arr[i] / exp) % 10]++;

            for (int i = 1; i < 10; i++)
                count[i] += count[i - 1];

            for (int i = n - 1; i >= 0; i--)
            {
                output[count[(arr[i] / exp) % 10] - 1] = arr[i];
                count[(arr[i] / exp) % 10]--;
            }

            for (int i = 0; i < n; i++)
                arr[i] = output[i];
        }

        static void BucketSort(int[] arr)
        {
            if (arr.Length == 0) return;

            int minValue = arr.Min();
            int maxValue = arr.Max();

            // Negatif sayıları desteklemek için normalizasyon gerekebilir ama
            // Basitlik adına pozitif varsayımı veya aralık hesabı yapıyoruz:

            // Kova sayısı (Genelde karekök n veya sabit sayı)
            int bucketCount = (int)Math.Sqrt(arr.Length) + 1;
            if (bucketCount < 1) bucketCount = 1;

            List<int>[] buckets = new List<int>[bucketCount];
            for (int i = 0; i < bucketCount; i++)
                buckets[i] = new List<int>();

            // Dağıtma
            int range = maxValue - minValue + 1;

            foreach (var item in arr)
            {
                // Hangi kovaya düşeceğini hesapla
                // Formül: (değer - min) / (aralık / kova_sayısı)
                double bucketIndexD = (double)(item - minValue) / range * (bucketCount - 1);
                int bucketIndex = (int)Math.Floor(bucketIndexD);

                buckets[bucketIndex].Add(item);
            }

            Console.WriteLine("Sayılar Kovalara Dağıtıldı:");
            for (int i = 0; i < buckets.Length; i++)
                Console.WriteLine($"Kova {i}: [{string.Join(", ", buckets[i])}]");

            // Sıralama ve Birleştirme
            int index = 0;
            for (int i = 0; i < buckets.Length; i++)
            {
                buckets[i].Sort(); // kendi içinde sırala
                foreach (var item in buckets[i])
                {
                    arr[index++] = item;
                }
            }
            PrintArray(arr, "Kovalar birleştirildi");
        }
    }
}