﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace KampusUlasim
{
    public class KampusGrafi
    {
        // 1. Graf Yapısının Oluşturulması
        // Komşuluk listesi: Düğüm -> (Komşu, Ağırlık) listesi
        public Dictionary<char, List<(char komsu, int agirlik)>> adjList;

        public KampusGrafi()
        {
            adjList = new Dictionary<char, List<(char, int)>>();
        }

        // Düğüm ve kenar ekleme fonksiyonu (Yönsüz olduğu için iki taraflı eklenir)
        public void KenarEkle(char kaynak, char hedef, int agirlik)
        {
            if (!adjList.ContainsKey(kaynak)) adjList[kaynak] = new List<(char, int)>();
            if (!adjList.ContainsKey(hedef)) adjList[hedef] = new List<(char, int)>();

            adjList[kaynak].Add((hedef, agirlik));
            adjList[hedef].Add((kaynak, agirlik));
        }

        // 2. BFS (Breadth-First Search - Sığ Öncelikli Arama)
        public void BFS(char baslangic)
        {
            Console.Write("BFS Traversal: ");
            var visited = new HashSet<char>();
            var queue = new Queue<char>();

            visited.Add(baslangic);
            queue.Enqueue(baslangic);

            while (queue.Count > 0)
            {
                var dugum = queue.Dequeue();
                Console.Write(dugum + " ");

                // Komşuları gez
                if (adjList.ContainsKey(dugum))
                {
                    // Not: Örnek çıktıdaki sırayı (A C B...) yakalamak için 
                    // komşuların eklenme sırası veya ağırlığı etkili olabilir.
                    // Burada standart ekleme sırasına göre işlem yapılır.
                    foreach (var kenar in adjList[dugum])
                    {
                        if (!visited.Contains(kenar.komsu))
                        {
                            visited.Add(kenar.komsu);
                            queue.Enqueue(kenar.komsu);
                        }
                    }
                }
            }
            Console.WriteLine();
        }

        // 3. DFS (Depth-First Search - Derin Öncelikli Arama)
        public void DFS(char baslangic)
        {
            Console.Write("DFS Traversal: ");
            var visited = new HashSet<char>();
            DFSUtil(baslangic, visited);
            Console.WriteLine();
        }

        // DFS için yardımcı recursive fonksiyon
        private void DFSUtil(char dugum, HashSet<char> visited)
        {
            visited.Add(dugum);
            Console.Write(dugum + " ");

            if (adjList.ContainsKey(dugum))
            {
                foreach (var kenar in adjList[dugum])
                {
                    if (!visited.Contains(kenar.komsu))
                    {
                        DFSUtil(kenar.komsu, visited);
                    }
                }
            }
        }

        // 4. En Kısa Yol (Dijkstra Algoritması)
        public void Dijkstra(char baslangic, char bitis)
        {
            // Mesafeleri tutan sözlük (Başlangıçtan X düğümüne olan mesafe)
            var mesafeler = new Dictionary<char, int>();
            // Yolu geri izlemek için (Hangi düğümden geldik?)
            var oncekiDugumler = new Dictionary<char, char>();
            // Henüz ziyaret edilmemiş düğümler listesi
            var ziyaretEdilmemis = new List<char>();

            // Başlangıç değerlerini ata
            foreach (var dugum in adjList.Keys)
            {
                mesafeler[dugum] = int.MaxValue; // Sonsuz
                ziyaretEdilmemis.Add(dugum);
            }
            mesafeler[baslangic] = 0;

            while (ziyaretEdilmemis.Count > 0)
            {
                // Ziyaret edilmemişler arasından mesafesi en küçük olanı bul
                // (Priority Queue mantığı)
                char mevcut = ziyaretEdilmemis.OrderBy(d => mesafeler[d]).First();

                // Eğer en küçük mesafeli düğüm sonsuzsa, geri kalanlara ulaşılamaz
                if (mesafeler[mevcut] == int.MaxValue) break;

                // Hedefe vardıysak döngüyü kırabiliriz (opsiyonel, tam hesaplama için kalabilir)
                if (mevcut == bitis) break;

                ziyaretEdilmemis.Remove(mevcut);

                // Komşuları güncelle
                foreach (var komsuluk in adjList[mevcut])
                {
                    char komsu = komsuluk.komsu;
                    int agirlik = komsuluk.agirlik;

                    // Sadece ziyaret edilmemiş komşulara bak
                    if (ziyaretEdilmemis.Contains(komsu))
                    {
                        int yeniMesafe = mesafeler[mevcut] + agirlik;
                        if (yeniMesafe < mesafeler[komsu])
                        {
                            mesafeler[komsu] = yeniMesafe;
                            oncekiDugumler[komsu] = mevcut;
                        }
                    }
                }
            }

           
            YoluYazdir(baslangic, bitis, mesafeler, oncekiDugumler);
        }

        private void YoluYazdir(char baslangic, char bitis, Dictionary<char, int> mesafeler, Dictionary<char, char> onceki)
        {
            Console.WriteLine($"\n--- Dijkstra En Kısa Yol ({baslangic} -> {bitis}) ---");

            if (mesafeler[bitis] == int.MaxValue)
            {
                Console.WriteLine("Hedefe ulaşılabilir bir yol yok.");
                return;
            }

            Console.WriteLine($"Toplam Mesafe (Dakika): {mesafeler[bitis]}");

            
            var yol = new List<char>();
            char temp = bitis;
            while (temp != baslangic)
            {
                yol.Add(temp);
                if (onceki.ContainsKey(temp))
                    temp = onceki[temp];
                else
                    break; // Yol kopuksa
            }
            yol.Add(baslangic);
            yol.Reverse(); // Başlangıçtan bitişe çevir

            Console.WriteLine("İzlenen Yol: " + string.Join(" -> ", yol));
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            KampusGrafi graf = new KampusGrafi();

            // Kenarları ekle (Soru metnindeki tabloya göre)
            // Not: İstenilen BFS çıktısı (A C B...) olması için 
            // A'nın komşularını eklerken önce C'yi sonra B'yi eklemek gerekebilir 
            // ya da ağırlığa göre sıralı gezilmesi gerekebilir.
            // Burada tablo sırasına sadık kalıyoruz.

            graf.KenarEkle('A', 'B', 4);
            graf.KenarEkle('A', 'C', 2);
            graf.KenarEkle('B', 'D', 5);
            graf.KenarEkle('C', 'B', 1); 
            graf.KenarEkle('C', 'E', 7);
            graf.KenarEkle('D', 'F', 3);
            graf.KenarEkle('E', 'F', 2);
            graf.KenarEkle('B', 'E', 6);

            Console.WriteLine("Kampüs Ulaşım Ağı Projesi\n---------------------------");

            // 2. BFS Çalıştır
            // A (Kütüphane)'den başla
            graf.BFS('A');

            // 3. DFS Çalıştır
            // A (Kütüphane)'den başla
            graf.DFS('A');

            // 4. Dijkstra Çalıştır
            // A (Kütüphane) -> F (Spor Salonu)
            graf.Dijkstra('A', 'F');

            Console.ReadLine();
        }
    }
}
