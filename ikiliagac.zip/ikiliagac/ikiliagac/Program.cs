﻿using System;
using System.Collections.Generic;

namespace BinaryTreeOdevi
{
    
    public class Node
    {
        public int Data;
        public Node Left;
        public Node Right;

        public Node(int item)
        {
            Data = item;
            Left = null;
            Right = null;
        }
    }

    
    public class BinaryTree
    {
        public Node Root;

        public BinaryTree()
        {
            Root = null;
        }

       
        public void Insert(int key)
        {
            Root = InsertRec(Root, key);
        }

        private Node InsertRec(Node root, int key)
        {
            
            if (root == null)
            {
                root = new Node(key);
                return root;
            }

            
            if (key < root.Data)
                root.Left = InsertRec(root.Left, key);
            else if (key > root.Data)
                root.Right = InsertRec(root.Right, key);

            return root;
        }

       
        public void PrintPreorder(Node node)
        {
            if (node == null) return;

            Console.Write(node.Data + " ");
            PrintPreorder(node.Left);
            PrintPreorder(node.Right);
        }

        
        public void PrintInorder(Node node)
        {
            if (node == null) return;

            PrintInorder(node.Left);
            Console.Write(node.Data + " ");
            PrintInorder(node.Right);
        }

        
        public void PrintPostorder(Node node)
        {
            if (node == null) return;

            PrintPostorder(node.Left);
            PrintPostorder(node.Right);
            Console.Write(node.Data + " ");
        }

        
        public void PrintLevelOrder()
        {
            if (Root == null) return;

            Queue<Node> queue = new Queue<Node>();
            queue.Enqueue(Root);

            while (queue.Count > 0)
            {
               
                Node tempNode = queue.Dequeue();
                Console.Write(tempNode.Data + " ");

                
                if (tempNode.Left != null)
                    queue.Enqueue(tempNode.Left);

                
                if (tempNode.Right != null)
                    queue.Enqueue(tempNode.Right);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            BinaryTree agac = new BinaryTree();

            
            Console.WriteLine("Ağaca eklemek istediğiniz sayıları girin.");
            Console.WriteLine("Girişi bitirmek için '-1' yazıp Enter'a basın.");
            Console.WriteLine("-------------------------------------------------");

            while (true)
            {
                Console.Write("Sayı giriniz: ");
                string giris = Console.ReadLine();

                if (int.TryParse(giris, out int sayi))
                {
                    if (sayi == -1) break; 
                    agac.Insert(sayi);
                }
                else
                {
                    Console.WriteLine("Lütfen geçerli bir sayı giriniz.");
                }
            }

            Console.WriteLine("\n--- SONUÇLAR ---\n");

           

            Console.Write("Preorder (Önce Kök): ");
            agac.PrintPreorder(agac.Root);
            Console.WriteLine();

            Console.Write("Inorder (Ortada Kök): ");
            agac.PrintInorder(agac.Root);
            Console.WriteLine();

            Console.Write("Postorder (Sonda Kök): ");
            agac.PrintPostorder(agac.Root);
            Console.WriteLine();

            Console.Write("Level-order (Katman): ");
            agac.PrintLevelOrder();
            Console.WriteLine();

            Console.WriteLine("\nÇıkmak için bir tuşa basın...");
            Console.ReadKey();
        }
    }
}
