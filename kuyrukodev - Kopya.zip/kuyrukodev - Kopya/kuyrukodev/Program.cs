﻿using System;
using System.Collections.Generic;
using System.Linq;

// Müşteri ve İşlem Bilgilerini Tutan Sınıf
public class Musteri
{
    public string AdSoyad { get; set; }
    public int IslemOnceligi { get; set; } // 1 (Yüksek), 2 (Orta), 3 (Düşük)
    public string IslemAdi { get; set; }

    public Musteri(string adSoyad, int oncelik, string islemAdi)
    {
        AdSoyad = adSoyad;
        IslemOnceligi = oncelik;
        IslemAdi = islemAdi;
    }

    public override string ToString()
    {
        return $"{AdSoyad} (İşlem: {IslemAdi}, Öncelik: {IslemOnceligi})";
    }
}

// Öncelikli Kuyruk Mantığını Yöneten Sınıf (Bağlı Liste Kullanarak)
public class BankaOncelikliKuyruk
{
    // Öncelik seviyelerine göre müşteri kuyruklarını tutan sözlük
    // Key: Öncelik seviyesi (1, 2, 3)
    // Value: Bağlı Liste (LinkedList<Musteri>)
    private readonly Dictionary<int, LinkedList<Musteri>> _kuyruklar;

    // Öncelik seviyeleri, en yüksekten en düşüğe sıralı
    private readonly List<int> _oncelikSirasi = new List<int> { 1, 2, 3 }; // 1: Yüksek, 3: Düşük

    public BankaOncelikliKuyruk()
    {
        _kuyruklar = new Dictionary<int, LinkedList<Musteri>>();
        // Her öncelik seviyesi için bir bağlı liste oluştur
        foreach (var oncelik in _oncelikSirasi)
        {
            _kuyruklar.Add(oncelik, new LinkedList<Musteri>());
        }
    }

    // Yeni Müşteri Ekleme (Enqueue)
    // Yeni kişiyi ait olduğu öncelik grubunun en sonuna ekler.
    public void Enqueue(Musteri musteri)
    {
        if (_kuyruklar.TryGetValue(musteri.IslemOnceligi, out var kuyruk))
        {
            // LinkedList'in AddLast metodu, elemanı listenin sonuna ekler (FIFO kuralını sağlar)
            kuyruk.AddLast(musteri);
            Console.WriteLine($" Eklendi: {musteri.AdSoyad} (Öncelik {musteri.IslemOnceligi}). Kuyruğa alındı.");
        }
        else
        {
            Console.WriteLine($"HATA: Geçersiz öncelik seviyesi ({musteri.IslemOnceligi}) ile müşteri eklenemedi.");
        }
    }

    // En Yüksek Öncelikli Müşteriyi Çıkarma ve İşleme Alma (Dequeue)
    // Kuyruktaki en yüksek seviyeli grubun ilk elemanını alır.
    public Musteri Dequeue()
    {
        foreach (var oncelik in _oncelikSirasi)
        {
            var kuyruk = _kuyruklar[oncelik];

            // İlgili öncelik grubunda eleman varsa
            if (kuyruk.Count > 0)
            {
                // Bağlı listenin ilk elemanı, bu gruptaki en eski (FIFO) ve en yüksek öncelikli müşteridir.
                Musteri islenecekMusteri = kuyruk.First.Value;
                kuyruk.RemoveFirst(); // Listenin başından kaldır
                Console.WriteLine($"\n➡️ İşleniyor: {islenecekMusteri.AdSoyad} (Öncelik {oncelik}).");
                return islenecekMusteri;
            }
        }

        // Tüm kuyruklar boşsa
        Console.WriteLine("\n Tüm kuyruklar boş. İşlenecek müşteri bulunamadı.");
        return null;
    }

    // Kuyruğun Mevcut Durumunu Görüntüleme
    public void KuyrukDurumunuGoster()
    {
        Console.WriteLine("\n--- BANKA KUYRUĞU GÜNCEL DURUMU ---");
        bool bosMu = true;
        foreach (var oncelik in _oncelikSirasi)
        {
            var kuyruk = _kuyruklar[oncelik];
            string musteriListesi = string.Join(" -> ", kuyruk.Select(m => m.AdSoyad));

            Console.Write($"Öncelik {oncelik} ({kuyruk.Count} kişi): ");

            if (kuyruk.Count > 0)
            {
                Console.ForegroundColor = oncelik == 1 ? ConsoleColor.Red : (oncelik == 2 ? ConsoleColor.Yellow : ConsoleColor.Green);
                Console.WriteLine(musteriListesi);
                Console.ResetColor();
                bosMu = false;
            }
            else
            {
                Console.WriteLine("Boş");
            }
        }
        if (bosMu)
        {
            Console.WriteLine("Tüm kuyruklar tamamen boş.");
        }
        Console.WriteLine("---------------------------------");
    }

    // Toplam Kuyruk Boyutunu Kontrol Etme
    public bool IsEmpty()
    {
        return _kuyruklar.Values.All(q => q.Count == 0);
    }
}

// Ana Program Sınıfı
public class Program
{
    // İşlem seçimine göre öncelik belirleme fonksiyonu
    public static (int, string) IslemSecimineGoreOncelikBelirle(string islem)
    {
        // 1: Yüksek Öncelik (Örn: Hesap Açma/Kapama, Kredi İşlemleri)
        // 2: Orta Öncelik (Örn: Para Yatırma/Çekme, Fatura Ödeme)
        // 3: Düşük Öncelik (Örn: Bilgi Alma, Broşür Talebi)
        switch (islem.ToLowerInvariant())
        {
            case "kredi":
                return (1, "Kredi Başvurusu");
            case "hesap":
                return (1, "Hesap İşlemleri");
            case "para çekme":
                return (2, "Para Çekme");
            case "fatura":
                return (2, "Fatura Ödeme");
            case "bilgi":
                return (3, "Genel Bilgi Alma");
            default:
                return (3, "Diğer İşlem");
        }
    }

    public static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        BankaOncelikliKuyruk bankaKuyrugu = new BankaOncelikliKuyruk();

        Console.WriteLine("<<< BANKA ÖNCELİKLİ KUYRUK SİMÜLASYONU (C# Linked List Mantığı) >>>\n");

        // 1. Müşterileri Kuyruğa Ekleme (Enqueue Fonksiyonu Çağrımı)
        Console.WriteLine("--- MÜŞTERİLER KUYRUĞA EKLENİYOR ---");

        void MusteriEkle(string ad, string islem)
        {
            var (oncelik, islemAdi) = IslemSecimineGoreOncelikBelirle(islem);
            Musteri yeniMusteri = new Musteri(ad, oncelik, islemAdi);
            bankaKuyrugu.Enqueue(yeniMusteri);
        }

        MusteriEkle("Ali Yılmaz", "para çekme"); // Öncelik 2
        MusteriEkle("Ayşe Demir", "kredi");       // Öncelik 1 (Yüksek)
        MusteriEkle("Can Kaya", "bilgi");         // Öncelik 3 (Düşük)
        MusteriEkle("Deniz Akın", "hesap");      // Öncelik 1
        MusteriEkle("Ece Soylu", "fatura");      // Öncelik 2
        MusteriEkle("Furkan Öz", "para çekme");   // Öncelik 2

        // Kuyruk Durumu 1
        bankaKuyrugu.KuyrukDurumunuGoster();

        // 2. Müşterileri İşleme Alma (Dequeue Fonksiyonu Çağrımı)
        Console.WriteLine("\n--- MÜŞTERİLER İŞLENİYOR ---");

        int islenenMusteriSayisi = 0;
        while (!bankaKuyrugu.IsEmpty() && islenenMusteriSayisi < 4) // İlk 4 müşteriyi işleyelim
        {
            Musteri islenen = bankaKuyrugu.Dequeue();
            if (islenen != null)
            {
                Console.WriteLine($"(Tamamlandı: {islenen.AdSoyad}'ın {islenen.IslemAdi} işlemi.)");
                islenenMusteriSayisi++;
            }
        }

        // Kuyruk Durumu 2 (4 Müşteri İşlendikten Sonra)
        bankaKuyrugu.KuyrukDurumunuGoster();

        // Yeni bir Yüksek Öncelikli müşteri ekleyelim
        MusteriEkle("Gülşen Tunç", "kredi"); // Öncelik 1
        bankaKuyrugu.KuyrukDurumunuGoster();

        // Kalan müşterileri işleyelim
        Console.WriteLine("\n--- KALAN MÜŞTERİLER İŞLENİYOR ---");
        while (!bankaKuyrugu.IsEmpty())
        {
            Musteri islenen = bankaKuyrugu.Dequeue();
            if (islenen != null)
            {
                Console.WriteLine($"(Tamamlandı: {islenen.AdSoyad}'ın {islenen.IslemAdi} işlemi.)");
            }
        }

        // Son Kuyruk Durumu
        bankaKuyrugu.KuyrukDurumunuGoster();

        Console.WriteLine("\nSimülasyon Sona Erdi.");
    }
}
