﻿using System;

public class HanoiKuleleri
{
    // Hamle sayısını takip etmek için bir sayaç
    private static int hamleSayisi = 0;

    static void Main(string[] args)
    {
        Console.WriteLine("Hanoi Kuleleri Çözümü (C#)");
        int diskSayisi = 0;

        
        while (diskSayisi <= 0)
        {
            Console.Write("Lütfen disk sayısını giriniz (örneğin 3): ");
            if (int.TryParse(Console.ReadLine(), out diskSayisi) && diskSayisi > 0)
            {
                break;
            }
            Console.WriteLine("Geçersiz giriş. Lütfen pozitif bir tamsayı giriniz.");
        }

        Console.WriteLine("\n--- Çözüm Adımları ---");

        // Başlangıç direk isimleri
        string kaynak = "Soldaki Direk (A)";
        string hedef = "Sağdaki Direk (C)";
        string yardimci = "Ortadaki Direk (B)";

        // Özyinelemeli fonksiyonu 
        CozHanoi(diskSayisi, kaynak, hedef, yardimci);

       
        Console.WriteLine("\n---------------------------------");
        Console.WriteLine($"Toplam disk sayısı: {diskSayisi}");
        Console.WriteLine($"Optimal (En az) hamle sayısı: {hamleSayisi}");
        // Matematiksel kontrol: Math.Pow(2, diskSayisi) - 1
        Console.WriteLine($"Matematiksel Kontrol: {Math.Pow(2, diskSayisi) - 1}");
        Console.WriteLine("---------------------------------");

        Console.WriteLine("Çıkmak için bir tuşa basın...");
        Console.ReadKey();
    }

    
    /// Hanoi Kuleleri problemini çözen özyinelemeli fonksiyon.
   
    /// <param name="n">Taşınacak disk sayısı.</param>
    /// <param name="kaynak">Disklerin bulunduğu direk.</param>
    /// <param name="hedef">Disklerin taşınacağı direk.</param>
    /// <param name="yardimci">Geçici olarak kullanılacak direk.</param>
    public static void CozHanoi(int n, string kaynak, string hedef, string yardimci)
    {
        // Temel Durum (Base Case): Tek bir disk kaldıysa, direkt hedefe taşı.
        if (n == 1)
        {
            Console.WriteLine($"[{++hamleSayisi}] Diski {kaynak}'tan {hedef}'e taşı.");
            return;
        }

        // 1. n-1 diski, Hedef direği kullanarak Yardımcı direğe taşı.
        CozHanoi(n - 1, kaynak, yardimci, hedef);

        // 2. En büyük diski Kaynak'tan Hedef direğe taşı.
        Console.WriteLine($"[{++hamleSayisi}] Diski {kaynak}'tan {hedef}'e taşı.");

        // 3. n-1 diski, Kaynak direği kullanarak Yardımcı direkten Hedef direğe taşı.
        CozHanoi(n - 1, yardimci, hedef, kaynak);
    }
}