﻿using System;
using System.Collections.Generic;

namespace KutuphaneSiralama
{
    // 1. Kitap Sınıfının Tanımlanması
    public class Kitap
    {
        public string KitapAdi { get; set; }
        public int BasimYili { get; set; }

        // Kurucu metot (Constructor)
        public Kitap(string kitapAdi, int basimYili)
        {
            KitapAdi = kitapAdi;
            BasimYili = basimYili;
        }

        // Ekrana yazdırmayı kolaylaştırmak için ToString override edildi
        public override string ToString()
        {
            return $"[{BasimYili}] - {KitapAdi}";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // 2. En az 6 kitap içeren listenin oluşturulması
            List<Kitap> kitaplar = new List<Kitap>
            {
                new Kitap("Sefiller", 1862),
                new Kitap("Suç ve Ceza", 1866),
                new Kitap("Harry Potter ve Felsefe Taşı", 1997),
                new Kitap("Don Kişot", 1605),
                new Kitap("1984", 1949),
                new Kitap("Yüzüklerin Efendisi", 1954),
                new Kitap("Simyacı", 1988)
            };

            // 3. Sıralamadan Önce Ekrana Yazdırma
            Console.WriteLine("--- SIRALAMADAN ÖNCE ---");
            ListeyiYazdir(kitaplar);

            // 4. Merge Sort Algoritmasının Çağrılması
            MergeSort(kitaplar, 0, kitaplar.Count - 1);

            // 5. Sıraladıktan Sonra Ekrana Yazdırma
            Console.WriteLine("\n--- SIRALADIKTAN SONRA (Basım Yılına Göre) ---");
            ListeyiYazdir(kitaplar);

            Console.ReadLine(); // Konsolun kapanmasını önlemek için
        }

        // Yardımcı Metot: Listeyi ekrana yazdırır
        static void ListeyiYazdir(List<Kitap> liste)
        {
            foreach (var kitap in liste)
            {
                Console.WriteLine(kitap.ToString());
            }
        }

        // --- MERGE SORT ALGORİTMASI ---

        // Ana sıralama fonksiyonu (Recursive/Özyinelemeli)
        static void MergeSort(List<Kitap> liste, int sol, int sag)
        {
            if (sol < sag)
            {
                // Orta noktayı bul
                int orta = sol + (sag - sol) / 2;

                // Birinci ve ikinci yarıları özyinelemeli olarak sırala
                MergeSort(liste, sol, orta);
                MergeSort(liste, orta + 1, sag);

                // Sıralı parçaları birleştir
                Merge(liste, sol, orta, sag);
            }
        }

        // İki alt diziyi birleştiren fonksiyon
        static void Merge(List<Kitap> liste, int sol, int orta, int sag)
        {
            // İki alt dizinin boyutlarını bul
            int n1 = orta - sol + 1;
            int n2 = sag - orta;

            // Geçici diziler oluştur
            Kitap[] SolDizi = new Kitap[n1];
            Kitap[] SagDizi = new Kitap[n2];

            // Verileri geçici dizilere kopyala
            for (int i = 0; i < n1; ++i)
                SolDizi[i] = liste[sol + i];
            for (int j = 0; j < n2; ++j)
                SagDizi[j] = liste[orta + 1 + j];

            // Geçici dizileri birleştirerek ana listeye geri yaz
            int x = 0, y = 0;
            int k = sol;

            while (x < n1 && y < n2)
            {
                // BURADA KARŞILAŞTIRMA YAPILIYOR: Basım Yılına Göre
                if (SolDizi[x].BasimYili <= SagDizi[y].BasimYili)
                {
                    liste[k] = SolDizi[x];
                    x++;
                }
                else
                {
                    liste[k] = SagDizi[y];
                    y++;
                }
                k++;
            }

            // SolDizi'de kalan eleman varsa kopyala
            while (x < n1)
            {
                liste[k] = SolDizi[x];
                x++;
                k++;
            }

            // SagDizi'de kalan eleman varsa kopyala
            while (y < n2)
            {
                liste[k] = SagDizi[y];
                y++;
                k++;
            }
        }
    }
}